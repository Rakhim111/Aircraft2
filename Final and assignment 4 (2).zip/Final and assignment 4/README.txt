Description:
The Aircraft website is a platform dedicated to aviation, designed for both ordinary users and administrators. It provides various content related to airplanes, airports, exchange rates and aircraft information.

Login Page:

Users can log in as administrators or as regular users. To log in, you must specify a username and password.
Admin Page:

On this page, administrators have access to site content management.
They can delete or change posts on the user's main page.
They can also update the images in the carousel on the main page.
User's page:

Users can choose from four different sections:
Main page: The main aviation-related content, news, articles and other materials are displayed here.
Map: This section offers an interactive map with information about various airports, routes and other aviation facilities.
Currency Exchange rate: Here users can find out the current exchange rates that are important for travel and aviation operations.
Aircraft Information: This section contains detailed information about the various types of aircraft, their characteristics and technical data.
User registration page:

On this page, new users can register by entering their email address and password.
After registration, they will have access to the main functions of the site, including the ability to view content, comment, etc.
The Aircraft website provides convenient access to aviation information for a wide range of users, providing both basic information and the ability to manage content for administrators.


Intuitive interface: The design of the site is designed with ease of use in mind, which makes navigation through various sections and functions easy and enjoyable.

Personalized Content: Users can customize their profile and receive personalized recommendations and notifications about aviation-related news, events and updates.

Using MongoDB Atlas: The MongoDB Atlas database provides reliable storage and processing of user data, posts, comments and other information on servers in the cloud, which guarantees scalability and reliability.

API with Aviation Stack: Integration with the Aviation Stack API allows the site to receive up-to-date information about flights, airlines, airports and other aspects of aviation, enriching the site's content and providing users with useful data.

Using the Mapbox API: An interactive map on the site is created using the Mapbox API, which allows users to easily find information about various airports, routes and geographical objects in the aviation industry.

Using the Currency API: Integration with the Currency API provides access to current exchange rates, which is especially useful for users planning travel or operations in the aviation sector.

It is written in Node.js: The Aircraft web application is developed using Node.js, which provides high performance, scalability and flexibility in development, and also provides the ability to use JavaScript both on the server side and on the client side.





TO LAUCNH THAT PRODUCT YOU NEED TO CREATE 2 ENV FILES(env.js and .env)
here is example env.js:
module.exports = {
    EMAIL: '',
    PASSWORD:'',
    
   }
// env.js
// env.js
let url1 = "";
let url2 = "";
let url3 = "";

function setUrl1(newUrl) {
    url1 = newUrl;
}

function setUrl2(newUrl) {
    url2 = newUrl;
}

function setUrl3(newUrl) {
    url3 = newUrl;
}

module.exports = { setUrl1, setUrl2, setUrl3 };

here is example .env:
MONGODB_URI
JWT_SECRET=
AVIATIONSTACK_API_KEY=
